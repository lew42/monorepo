import fs from "node:fs";
import path from "node:path";

// Synthetic page.jsonl tree: 4 levels deep, 5 children per level, 20 lines per page.jsonl.
// Worktree-only, deleted after measurement (ai/log-assistant rule: nothing here is committed).
const ROOT = path.join(import.meta.dirname, "synth");
const LEVELS = 4, FANOUT = 5, LINES = 20;

function build(dir, level){
	fs.mkdirSync(dir, { recursive: true });
	const lines = [{ title: `Synth L${level}`, is: "card" }];
	const kids = level < LEVELS ? Array.from({ length: FANOUT }, (_, i) => `k${i}`) : [];
	kids.forEach(k => lines.push({ file: `${k}/page.jsonl` }));
	while (lines.length < LINES) lines.push({ tab: { name: `pad${lines.length}`, title: "x", nav: false } });
	fs.writeFileSync(path.join(dir, "page.jsonl"), lines.map(l => JSON.stringify(l)).join("\n") + "\n");
	kids.forEach(k => build(path.join(dir, k), level + 1));
}

build(ROOT, 1);
console.log("built", ROOT);
