import Browser from "../../../../../../../../../../Server/Browser.mjs";

const BASE = process.argv[2] || "http://127.0.0.1:53715";
const urls = [
	"/live/",
	"/live/design/",
	"/framework/core/Page/",
	"/framework/ai/sessions/2026/11/06/",
];

const browser = await Browser.browser();
const results = [];

for (const path of urls) {
	const page = await browser.newPage();
	const reqs = [];
	let firstRenderAt = null;
	const t0 = Date.now();

	page.on("response", async res => {
		const u = res.url();
		if (!u.endsWith(".jsonl")) return;
		let bytes = 0;
		try { bytes = (await res.body()).length; } catch {}
		reqs.push({ url: u.replace(BASE, ""), bytes, at: Date.now() - t0 });
	});

	await page.goto(BASE + path, { waitUntil: "networkidle", timeout: 30000 }).catch(e => console.error("goto failed", path, e.message));
	// first paint proxy: time to first jsonl response back, and time to DOMContentLoaded
	const domAt = Date.now() - t0;

	const totalBytes = reqs.reduce((s, r) => s + r.bytes, 0);
	const depths = reqs.map(r => r.url.split("/").filter(Boolean).length);
	const maxDepth = depths.length ? Math.max(...depths) : 0;

	results.push({
		path, count: reqs.length, totalBytes, maxDepth, domAt,
		firstReq: reqs[0]?.at ?? null, lastReq: reqs[reqs.length - 1]?.at ?? null,
		files: reqs.map(r => r.url),
	});
	await page.close();
}

await Browser.close();
console.log(JSON.stringify(results, null, 2));
