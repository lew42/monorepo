import Browser from "../../../../../../../../../../Server/Browser.mjs";

const BASE = process.argv[2] || "http://127.0.0.1:53715";
const path_ = "/framework/core/Page/synth-test/";

const browser = await Browser.browser();
const page = await browser.newPage();
const reqs = [];
const t0 = Date.now();

page.on("response", async res => {
	const u = res.url();
	if (!u.endsWith(".jsonl")) return;
	let bytes = 0;
	try { bytes = (await res.body()).length; } catch {}
	reqs.push({ url: u.replace(BASE, ""), bytes, at: Date.now() - t0 });
});

await page.goto(BASE + path_, { waitUntil: "networkidle", timeout: 30000 }).catch(e => console.error("goto failed", e.message));
const domAt = Date.now() - t0;

const synthReqs = reqs.filter(r => r.url.includes("/synth-test/"));
const totalBytes = synthReqs.reduce((s, r) => s + r.bytes, 0);

console.log(JSON.stringify({
	totalJsonlRequests: reqs.length,
	synthPageJsonlRequests: synthReqs.length,
	synthBytes: totalBytes,
	domAt,
	lastReq: reqs[reqs.length - 1]?.at ?? null,
	synthFiles: synthReqs.map(r => r.url),
}, null, 2));

await Browser.close();
